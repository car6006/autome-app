#!/usr/bin/env python3
"""
AUTO-ME PWA File Organization Script
Automatically organizes scattered files in the root directory into proper folders
"""

import os
import glob
import shutil
from datetime import datetime

def organize_files():
    """Organize scattered files in the root directory"""
    root_dir = "/app"
    
    # Define target directories
    directories = {
        "dev-tools": os.path.join(root_dir, "dev-tools"),
        "logs": os.path.join(root_dir, "logs"), 
        "test-data": os.path.join(root_dir, "test-data"),
        "docs": os.path.join(root_dir, "docs")
    }
    
    # Ensure directories exist
    for dir_path in directories.values():
        os.makedirs(dir_path, exist_ok=True)
    
    moved_files = []
    
    # Organize Python debug/dev scripts (except main application files)
    for py_file in glob.glob(os.path.join(root_dir, "*.py")):
        if os.path.basename(py_file) not in ["server.py", "pipeline_worker.py", "auth.py", "store.py", "providers.py", "tasks.py"]:
            target = os.path.join(directories["dev-tools"], os.path.basename(py_file))
            if not os.path.exists(target):
                shutil.move(py_file, target)
                moved_files.append(f"  {os.path.basename(py_file)} → dev-tools/")
    
    # Organize log files
    for log_file in glob.glob(os.path.join(root_dir, "*.log")):
        target = os.path.join(directories["logs"], os.path.basename(log_file))
        if not os.path.exists(target):
            shutil.move(log_file, target)
            moved_files.append(f"  {os.path.basename(log_file)} → logs/")
    
    # Organize test audio/data files
    test_extensions = ["*.mp3", "*.wav", "*.json", "*.csv", "*.txt"]
    for ext in test_extensions:
        for file_path in glob.glob(os.path.join(root_dir, ext)):
            filename = os.path.basename(file_path)
            # Skip important config files
            if filename not in ["package.json", "test_result.md", "yarn.lock"]:
                # Check if it looks like test data
                if any(keyword in filename.lower() for keyword in ["test", "sample", "demo", "regional_meeting"]):
                    target = os.path.join(directories["test-data"], filename)
                    if not os.path.exists(target):
                        shutil.move(file_path, target)
                        moved_files.append(f"  {filename} → test-data/")
    
    # Organize additional documentation (keep main docs in root)
    main_docs = ["README.md", "CHANGELOG.md", "DEPLOYMENT.md", "PRODUCTIVITY_METRICS.md", 
                 "TROUBLESHOOTING.md", "WORK_SUMMARY.md", "DIRECTORY_STRUCTURE.md"]
    
    for md_file in glob.glob(os.path.join(root_dir, "*.md")):
        filename = os.path.basename(md_file)
        if filename not in main_docs:
            target = os.path.join(directories["docs"], filename)
            if not os.path.exists(target):
                shutil.move(md_file, target)
                moved_files.append(f"  {filename} → docs/")
    
    # Report results
    print(f"🧹 File Organization Complete - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    if moved_files:
        print(f"📁 Moved {len(moved_files)} files:")
        for file_move in moved_files:
            print(file_move)
    else:
        print("✅ All files already properly organized!")
    
    # Show current organization status
    print(f"\n📊 Current Organization:")
    for name, path in directories.items():
        count = len([f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))])
        print(f"  {name}: {count} files")

if __name__ == "__main__":
    organize_files()