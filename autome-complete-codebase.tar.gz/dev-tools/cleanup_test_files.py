#!/usr/bin/env python3
"""
Quick cleanup script to remove unnecessary test files
Keeps important test files but removes clutter
"""

import os
import shutil
from pathlib import Path

def cleanup_test_files():
    """Remove unnecessary test files while keeping important ones"""
    
    # Files/directories to keep (important test files)
    keep_files = {
        '/app/test_result.md',  # Important test results
        '/app/backend_test.py',  # Useful backend test script
        '/app/tests/test_rate_limiting.py',  # Rate limiting tests
    }
    
    # Directories to clean up
    cleanup_dirs = [
        '/app/logs',  # Old log files
        '/app/test-data',  # Old test data
        '/tmp/autome_storage',  # Temporary storage
    ]
    
    # Patterns to delete (but not in node_modules)
    delete_patterns = [
        'temp_*',
        '*_test_*',
        '*.tmp',
        '*.cache',
        'debug_*',
        'test_audio_*',
        'sample_*'
    ]
    
    files_deleted = 0
    space_freed = 0
    
    print("🧹 Starting test file cleanup...")
    
    # Clean up specific directories
    for dir_path in cleanup_dirs:
        if os.path.exists(dir_path):
            try:
                # Count files and size before deletion
                for root, dirs, files in os.walk(dir_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        if os.path.exists(file_path):
                            space_freed += os.path.getsize(file_path)
                            files_deleted += 1
                
                shutil.rmtree(dir_path)
                print(f"🗑️  Removed directory: {dir_path}")
            except Exception as e:
                print(f"❌ Failed to remove {dir_path}: {e}")
    
    # Clean up files matching patterns (excluding node_modules and important files)
    for root, dirs, files in os.walk('/app'):
        # Skip node_modules
        if 'node_modules' in root:
            continue
            
        for file in files:
            file_path = os.path.join(root, file)
            
            # Skip important files
            if file_path in keep_files:
                continue
                
            # Check if matches delete patterns
            should_delete = False
            for pattern in delete_patterns:
                if pattern.startswith('*') and file.endswith(pattern[1:]):
                    should_delete = True
                    break
                elif pattern.endswith('*') and file.startswith(pattern[:-1]):
                    should_delete = True
                    break
                elif file == pattern:
                    should_delete = True
                    break
            
            if should_delete:
                try:
                    file_size = os.path.getsize(file_path)
                    os.remove(file_path)
                    space_freed += file_size
                    files_deleted += 1
                    print(f"🗑️  Deleted: {file}")
                except Exception as e:
                    print(f"❌ Failed to delete {file_path}: {e}")
    
    # Format space freed
    def format_bytes(bytes_val):
        for unit in ['B', 'KB', 'MB', 'GB']:
            if bytes_val < 1024.0:
                return f"{bytes_val:.1f} {unit}"
            bytes_val /= 1024.0
        return f"{bytes_val:.1f} TB"
    
    print(f"\n✅ Cleanup completed!")
    print(f"📊 Files deleted: {files_deleted}")
    print(f"💾 Space freed: {format_bytes(space_freed)}")
    
    if files_deleted == 0:
        print("🎉 No unnecessary test files found - system is clean!")

if __name__ == "__main__":
    cleanup_test_files()
    print("\n💡 For ongoing maintenance, use the archive system:")
    print("   python /app/backend/archive_manager.py --dry-run")
    print("   python /app/backend/archive_manager.py --days 30")