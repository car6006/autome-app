#!/usr/bin/env python3
"""
Setup automatic archive cron job for AUTO-ME PWA
This script creates a cron job to automatically clean up old files
"""

import os
import subprocess
from pathlib import Path

def setup_cron_job():
    """Setup cron job for automatic archiving"""
    
    # Cron job configuration
    archive_script_path = "/app/backend/archive_manager.py"
    log_file = "/var/log/autome_archive.log"
    
    # Different cron schedules (user can choose)
    cron_schedules = {
        "daily": "0 2 * * *",      # Daily at 2 AM
        "weekly": "0 2 * * 0",     # Weekly on Sunday at 2 AM
        "monthly": "0 2 1 * *",    # Monthly on 1st at 2 AM
    }
    
    print("🗂️  AUTO-ME Archive Cron Job Setup")
    print("=" * 40)
    
    # Check if archive manager exists
    if not os.path.exists(archive_script_path):
        print(f"❌ Archive manager not found at: {archive_script_path}")
        return False
    
    print("Available schedules:")
    for key, schedule in cron_schedules.items():
        print(f"  {key}: {schedule}")
    
    # Get user preference
    while True:
        choice = input("\nChoose schedule (daily/weekly/monthly) [weekly]: ").strip().lower()
        if not choice:
            choice = "weekly"
        if choice in cron_schedules:
            break
        print("Invalid choice. Please choose daily, weekly, or monthly.")
    
    selected_schedule = cron_schedules[choice]
    
    # Create cron job command
    cron_command = f"cd /app/backend && /usr/bin/python3 {archive_script_path} >> {log_file} 2>&1"
    cron_line = f"{selected_schedule} {cron_command}"
    
    print(f"\n📅 Selected schedule: {choice}")
    print(f"🕐 Cron expression: {selected_schedule}")
    print(f"📝 Log file: {log_file}")
    print(f"🔧 Command: {cron_command}")
    
    # Confirm with user
    confirm = input("\nProceed with cron job setup? (y/N): ").strip().lower()
    if confirm != 'y':
        print("❌ Cron job setup cancelled.")
        return False
    
    try:
        # Get current cron jobs
        result = subprocess.run(['crontab', '-l'], capture_output=True, text=True)
        current_cron = result.stdout if result.returncode == 0 else ""
        
        # Check if archive job already exists
        if "archive_manager.py" in current_cron:
            print("⚠️  Archive cron job already exists. Updating...")
            # Remove existing archive job
            lines = current_cron.split('\n')
            filtered_lines = [line for line in lines if "archive_manager.py" not in line]
            current_cron = '\n'.join(filtered_lines).strip()
        
        # Add new cron job
        new_cron = current_cron + '\n' + cron_line if current_cron else cron_line
        
        # Write new cron jobs
        process = subprocess.Popen(['crontab', '-'], stdin=subprocess.PIPE, text=True)
        process.communicate(input=new_cron)
        
        if process.returncode == 0:
            print("✅ Cron job setup successfully!")
            print(f"🗂️  Archive will run {choice} and logs will be saved to {log_file}")
            
            # Create log file if it doesn't exist
            Path(log_file).touch()
            
            # Show current cron jobs
            print("\n📋 Current cron jobs:")
            subprocess.run(['crontab', '-l'])
            
            return True
        else:
            print("❌ Failed to setup cron job")
            return False
            
    except Exception as e:
        print(f"❌ Error setting up cron job: {e}")
        return False

def remove_cron_job():
    """Remove archive cron job"""
    try:
        # Get current cron jobs
        result = subprocess.run(['crontab', '-l'], capture_output=True, text=True)
        current_cron = result.stdout if result.returncode == 0 else ""
        
        if "archive_manager.py" not in current_cron:
            print("ℹ️  No archive cron job found.")
            return True
        
        # Remove archive job
        lines = current_cron.split('\n')
        filtered_lines = [line for line in lines if "archive_manager.py" not in line and line.strip()]
        new_cron = '\n'.join(filtered_lines)
        
        # Write updated cron jobs
        process = subprocess.Popen(['crontab', '-'], stdin=subprocess.PIPE, text=True)
        process.communicate(input=new_cron)
        
        if process.returncode == 0:
            print("✅ Archive cron job removed successfully!")
            return True
        else:
            print("❌ Failed to remove cron job")
            return False
            
    except Exception as e:
        print(f"❌ Error removing cron job: {e}")
        return False

def show_archive_status():
    """Show current archive configuration and status"""
    print("📊 Current Archive Configuration")
    print("=" * 35)
    
    # Check environment variables
    archive_days = os.environ.get('ARCHIVE_DAYS', '30')
    print(f"🗓️  Archive after: {archive_days} days")
    
    # Check cron job status
    try:
        result = subprocess.run(['crontab', '-l'], capture_output=True, text=True)
        if result.returncode == 0 and "archive_manager.py" in result.stdout:
            for line in result.stdout.split('\n'):
                if "archive_manager.py" in line:
                    print(f"⏰ Cron job: {line.strip()}")
                    break
        else:
            print("⏰ Cron job: Not configured")
    except:
        print("⏰ Cron job: Unable to check")
    
    # Check log file
    log_file = "/var/log/autome_archive.log"
    if os.path.exists(log_file):
        file_size = os.path.getsize(log_file)
        print(f"📝 Log file: {log_file} ({file_size} bytes)")
    else:
        print(f"📝 Log file: Not created yet")
    
    print(f"\n💡 Manual commands:")
    print(f"   Dry run: cd /app/backend && python archive_manager.py --dry-run")
    print(f"   Execute: cd /app/backend && python archive_manager.py")
    print(f"   Custom:  cd /app/backend && python archive_manager.py --days 60")

def main():
    """Main function"""
    import sys
    
    if len(sys.argv) > 1:
        action = sys.argv[1].lower()
        if action == "remove":
            remove_cron_job()
        elif action == "status":
            show_archive_status()
        else:
            print("Usage: python setup_archive_cron.py [remove|status]")
    else:
        setup_cron_job()

if __name__ == "__main__":
    main()